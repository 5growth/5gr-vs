git clone https://github.com/5growth/$1.git $2

