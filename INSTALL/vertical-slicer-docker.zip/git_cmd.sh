cmd="git clone https://github.com/nextworks-it/$1.git $2"
echo $cmd
$cmd


