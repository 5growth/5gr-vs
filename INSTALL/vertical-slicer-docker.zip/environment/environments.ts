// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
​/*
export const environment = {
   baseUrl: 'http://10.30.8.103:8082/',
   //baseUrl: 'http://10.30.8.76:8082/',
   stepsToRoot : 4,
   stopRefreshing : false,
   isShowingProgress : false,
   deploymentType :'VSMF'
};
*/
export const environment = {
    baseUrl: 'http://10.30.8.69:8082/',
    //baseUrl: 'http://10.30.8.76:8082/',
    stepsToRoot : 4,
    stopRefreshing : false,
    isShowingProgress : false,
    deploymentType :'VSMF/NSMF'
 };