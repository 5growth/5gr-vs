STEPS:

1) Edit environment/environments.ts  to set the external IP address where the backend will be accessible
2) Edit sebatian/sebastian_application.properties to adjust the backend configuration
3) Run docker-compose up and enjoy
